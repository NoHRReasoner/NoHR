This directory subtree is extracted from the Prolog Studio source tree, using its ip.sh script

Software therein, with the exception of the externalJars directory contents, is all open source licensed as per Apache 2.0. 

Copyright Renting Point, Lda. (Portugal) and other entities. More detailed information at interprolog.com and in the source files.